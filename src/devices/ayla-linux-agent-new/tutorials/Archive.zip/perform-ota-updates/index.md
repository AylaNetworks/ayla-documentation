---
title: Perform OTA Updates
layout: devices-ayla-linux-agent.html
b: block
---

This tutorial shows you how to update the host application and Ayla Linux Agent running on your RPi.

UNDER CONSTRUCTION.